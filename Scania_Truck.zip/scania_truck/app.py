from flask import Flask, render_template
from sklearn.linear_model import LogisticRegression
import joblib
import pandas as pd
from flask import jsonify, request
import numpy as np
from sklearn.impute import SimpleImputer
from sklearn.impute import KNNImputer
from sklearn.linear_model import Ridge
from sympy import re
import time



app = Flask(__name__)


@app.route("/")
def hello():
    return render_template("index.html")

@app.route('/predict', methods = ['POST'])
def predict():
    path = request.form.to_dict()
    print(path)
    
    # here we take the path of inpute file
    data = pd.read_csv(path["inFile"] , na_values=["na"])


    # our data have missing value to deal with this problem we are using the median imputer to impute the missing data
    median_imputer = joblib.load('median_impute.pkl')

    # here we are loading the logistic regression model 
    model = joblib.load('model.pkl')

    # here we are giing to replace the na value to np.NaN value 
    data = data.replace('na', np.NaN)

    # here we droping the those feature name which have more than 75% of missing value and which data have std_daviation is zero
    data = data.drop(['cd_000', 'br_000', 'bq_000', 'bp_000', 'bq_000', 'bo_000','ab_000','cr_000'], axis = 1)
    
    # here we are manualy selecting the those feature name which have less than 15% missing values
    median_data = ['aa_000', 'ac_000','ae_000','af_000','ag_001','ag_002','ag_003','ag_004','ag_005','ag_006','ag_007','ag_008','ag_009','ah_000','ai_000','aj_000','ak_000','al_000','am_0','an_000','ao_000','ap_000','aq_000','ar_000','as_000','at_000','au_000','av_000','ax_000','ay_000','ay_001','ay_002','ay_003','ay_004','ay_005','ay_006','ay_007','ay_008','ay_009','az_000','az_001','az_002','az_003','az_004','az_005','az_006','az_007','az_008','az_009','ba_000','ba_001','ba_002','ba_003','ba_004','ba_005','ba_006','ba_007','ba_008','ba_009','bb_000','bc_000','bd_000','be_000','bf_000','bg_000','bh_000','bi_000','bj_000','bs_000','bt_000','bu_000','bv_000','bx_000','by_000','bz_000','ca_000','cc_000','ce_000','ci_000','cj_000','ck_000','cn_000','cn_001','cn_002','cn_003','cn_004','cn_005','cn_006','cn_007','cn_008','cn_009','cp_000','cq_000','cs_000','cs_001','cs_002','cs_003','cs_004','cs_005','cs_006','cs_007','cs_008','cs_009','dd_000','de_000','df_000','dg_000','dh_000','di_000','dj_000','dk_000','dl_000','dm_000','dn_000','do_000','dp_000','dq_000','dr_000','ds_000','dt_000','du_000','dv_000','dx_000','dy_000','dz_000','ea_000','eb_000','ee_000','ee_001','ee_002','ee_003','ee_004','ee_005','ee_006','ee_007','ee_008','ee_009','ef_000','eg_000']
    
    # here we are selecting the those feature which have less than 75% and more than 15% missing values 
    model_data = ['ad_000', 'bk_000', 'bl_000', 'bm_000', 'bn_000', 'cf_000', 'cg_000','ch_000', 'cl_000', 'cm_000', 'co_000', 'ct_000', 'cu_000', 'cv_000','cx_000', 'cy_000', 'cz_000', 'da_000', 'db_000', 'dc_000', 'ec_00','ed_000']
    
    # here we are seprating those feature which are going to impute by median_imputation from data set
    median_df = data.filter(median_data)

    # here we are seperating the model_impute feature
    model_df = data.filter(model_data)

    median_imp = median_imputer.fit_transform(median_df)
    
    # making the data frame 
    median_imp_df = pd.DataFrame(median_imp, columns= median_df.columns)
    
    # KNN imputation 
    imputer = KNNImputer()
    model_imp_test = imputer.fit_transform(model_df)
    model_imp_df = pd.DataFrame(model_imp_test, columns= model_df.columns)
    
    # here we are concatinating the median_imputed dataframe and model_imputed data
    data_df = pd.concat((median_imp_df, model_imp_df), axis = 1)

    data['class'] = model.predict(data_df)


    timestr = time.strftime("%Y%m%d-%H%M%S")
    
    # here we specifing the path of ouput directory
    data.to_csv( path['outFile'] + '\\output_' + str(timestr) + '.csv' , index=False )
    
    return ('Process is completed, Please checkout the output directory')




if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8080)